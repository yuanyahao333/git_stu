CPack Cygwin Generator
----------------------

Cygwin CPack generator (Cygwin).

Variables affecting the CPack Cygwin generator
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

- .. versionadded:: 3.18
    :variable:`CPACK_ARCHIVE_THREADS`


Variables specific to CPack Cygwin generator
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The
following variable is specific to installers build on and/or for
Cygwin:

.. variable:: CPACK_CYGWIN_PATCH_NUMBER

 The Cygwin patch number.  FIXME: This documentation is incomplete.

.. variable:: CPACK_CYGWIN_PATCH_FILE

 The Cygwin patch file.  FIXME: This documentation is incomplete.

.. variable:: CPACK_CYGWIN_BUILD_SCRIPT

 The Cygwin build script.  FIXME: This documentation is incomplete.
